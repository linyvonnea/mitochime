from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch, Circle, FancyArrowPatch, Polygon
from matplotlib.lines import Line2D

OUT = Path(__file__).parent / 'figures'
OUT.mkdir(exist_ok=True)

DARK = '#111827'
BLUE = '#2563EB'
CYAN = '#06B6D4'
GREEN = '#22C55E'
RED = '#EF4444'
YELLOW = '#FACC15'
GRAY = '#6B7280'
LIGHT = '#F9FAFB'
PURPLE = '#8B5CF6'
ORANGE = '#F97316'
MAGENTA = '#EC4899'

plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['axes.labelsize'] = 12

def clean(ax):
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)

def save(fig, name):
    fig.savefig(OUT / name, bbox_inches='tight', pad_inches=0.05)
    plt.close(fig)

def star_background(name):
    rng = np.random.default_rng(42)
    fig, ax = plt.subplots(figsize=(16,9))
    ax.set_facecolor(DARK)
    clean(ax)
    xs, ys = rng.random(180), rng.random(180)
    sizes = rng.uniform(5, 35, size=180)
    ax.scatter(xs, ys, s=sizes, c='white', alpha=rng.uniform(0.25,0.9,180), linewidths=0)
    # curved DNA-like line
    t = np.linspace(0, 1, 500)
    x = t
    y1 = 0.5 + 0.12*np.sin(2*np.pi*4*t)
    y2 = 0.5 - 0.12*np.sin(2*np.pi*4*t)
    ax.plot(x, y1, color=CYAN, lw=3, alpha=.55)
    ax.plot(x, y2, color=PURPLE, lw=3, alpha=.55)
    for i in np.linspace(0.04, .96, 30):
        yy1 = 0.5 + 0.12*np.sin(2*np.pi*4*i)
        yy2 = 0.5 - 0.12*np.sin(2*np.pi*4*i)
        ax.plot([i,i], [yy1,yy2], color='white', lw=1, alpha=.25)
    ax.set_xlim(0,1); ax.set_ylim(0,1)
    save(fig, name)

star_background('title_background.pdf')
star_background('final_title_background.pdf')

# impostor_reads.pdf
fig, ax = plt.subplots(figsize=(10,6))
ax.set_facecolor(DARK); clean(ax); ax.set_xlim(0,10); ax.set_ylim(0,6)
ax.text(0.5,5.55,'Two reads enter assembly...', color='white', fontsize=20, weight='bold')
# Read A clean
ax.text(0.7,4.5,'Read A', color='white', fontsize=16, weight='bold')
ax.add_patch(FancyBboxPatch((2,4.05),6.6,.45, boxstyle='round,pad=0.08,rounding_size=0.16', fc=GREEN, ec='none'))
for x in np.linspace(2.2,8.3,18):
    ax.plot([x,x+.12],[4.08,4.47], color='white', alpha=.35, lw=1)
ax.text(3.6,3.6,'continuous alignment', color='#D1FAE5', fontsize=12)
# Read B chimera unknown
ax.text(0.7,2.5,'Read B', color='white', fontsize=16, weight='bold')
ax.add_patch(FancyBboxPatch((2,2.05),3.1,.45, boxstyle='round,pad=0.08,rounding_size=0.16', fc=CYAN, ec='none'))
ax.add_patch(FancyBboxPatch((5.35,2.05),3.25,.45, boxstyle='round,pad=0.08,rounding_size=0.16', fc=YELLOW, ec='none'))
ax.add_patch(Rectangle((5.16,1.92),.15,.7,fc=RED,ec='none'))
ax.text(4.65,1.55,'junction?', color=RED, fontsize=13, weight='bold')
ax.plot([5.23,5.23],[1.8,2.72], color=RED, lw=2, ls='--')
for x in np.linspace(2.2,4.9,8):
    ax.plot([x,x+.12],[2.08,2.47], color='white', alpha=.35, lw=1)
for x in np.linspace(5.55,8.35,8):
    ax.plot([x,x+.12],[2.08,2.47], color=DARK, alpha=.35, lw=1)
ax.text(2.25,.55,'Question: which pattern looks artificially joined?', color='white', fontsize=15)
save(fig,'impostor_reads.pdf')

# PCR chimera
fig, ax = plt.subplots(figsize=(10,7))
ax.set_facecolor('white'); clean(ax); ax.set_xlim(0,10); ax.set_ylim(0,7)
ax.text(0.4,6.45,'PCR-induced chimera formation', fontsize=20, color=DARK, weight='bold')
# template 1 and 2
ax.add_patch(FancyBboxPatch((0.8,5.2),7.2,.35, boxstyle='round,pad=0.04', fc=CYAN, ec='none'))
ax.text(8.2,5.2,'Template 1', fontsize=12, color=GRAY)
ax.add_patch(FancyBboxPatch((0.8,4.3),7.2,.35, boxstyle='round,pad=0.04', fc=YELLOW, ec='none'))
ax.text(8.2,4.3,'Template 2', fontsize=12, color=GRAY)
# incomplete extension
ax.add_patch(FancyBboxPatch((0.8,3.15),3.2,.35, boxstyle='round,pad=0.04', fc=CYAN, ec='none'))
ax.text(4.2,3.12,'Incomplete extension', fontsize=12, color=GRAY)
# arrow down
ax.add_patch(FancyArrowPatch((4.7,2.85),(4.7,2.25),arrowstyle='-|>', mutation_scale=18, lw=2, color=GRAY))
ax.text(5.0,2.48,'template switching', fontsize=12, color=RED)
# final chimera
ax.add_patch(FancyBboxPatch((0.8,1.35),3.3,.45, boxstyle='round,pad=0.05', fc=CYAN, ec='none'))
ax.add_patch(FancyBboxPatch((4.25,1.35),3.75,.45, boxstyle='round,pad=0.05', fc=YELLOW, ec='none'))
ax.add_patch(Rectangle((4.08,1.22),.14,.7,fc=RED,ec='none'))
ax.text(2.9,.75,'Chimeric read: segment from one region joined to another', fontsize=13, color=DARK, ha='center')
save(fig,'pcr_chimera.pdf')

# tool gap matrix
fig, ax = plt.subplots(figsize=(12,6.8))
clean(ax); ax.set_xlim(0,12); ax.set_ylim(0,6.8)
ax.text(0.3,6.35,'Where existing tools fit - and where MitoChime fits', fontsize=18, weight='bold', color=DARK)
cols = ['Amplicon','ASV/OTU','Read-level','Mito PCR\nchimera']
rows = ['UCHIME','DADA2','CATCh','ChimPipe','MitoChime']
x0, y0 = 2.4, 5.45
cw, rh = 2.1, .75
# headers
for j,c in enumerate(cols):
    ax.add_patch(Rectangle((x0+j*cw,y0),cw,rh,fc=DARK,ec='white',lw=1))
    ax.text(x0+j*cw+cw/2,y0+rh/2,c,ha='center',va='center',color='white',fontsize=11,weight='bold')
for i,r in enumerate(rows):
    y = y0-(i+1)*rh
    ax.add_patch(Rectangle((0.3,y),2.1,rh,fc=LIGHT if r!='MitoChime' else '#DBEAFE',ec='white',lw=1))
    ax.text(1.35,y+rh/2,r,ha='center',va='center',color=DARK,fontsize=12,weight='bold' if r=='MitoChime' else None)
    values = {
        'UCHIME':['yes','yes','limited','no'],
        'DADA2':['yes','yes','no','no'],
        'CATCh':['yes','yes','no','no'],
        'ChimPipe':['no','no','yes','different'],
        'MitoChime':['no','no','yes','yes'],
    }[r]
    for j,v in enumerate(values):
        fc = 'white' if r!='MitoChime' else '#EFF6FF'
        ax.add_patch(Rectangle((x0+j*cw,y),cw,rh,fc=fc,ec='white',lw=1))
        color = GREEN if v=='yes' else (YELLOW if v in ['limited','different'] else RED)
        text = '✓' if v=='yes' else ('△' if v in ['limited','different'] else '×')
        ax.text(x0+j*cw+cw/2,y+rh/2,text,ha='center',va='center',color=color,fontsize=20,weight='bold')
ax.text(0.3,.45,'Gap: direct read-level detection for PCR-induced mitochondrial chimeras', fontsize=14, color=BLUE, weight='bold')
save(fig,'tool_gap_matrix.pdf')

# methodology.png
fig, ax = plt.subplots(figsize=(14,7))
clean(ax); ax.set_xlim(0,14); ax.set_ylim(0,7)
ax.text(0.4,6.35,'MitoChime workflow', fontsize=22, weight='bold', color=DARK)
steps=[('Reference\ngenome',BLUE),('Simulate\nreads',CYAN),('Align\nreads',PURPLE),('Extract\nfeatures',ORANGE),('Train\nmodels',GREEN),('Filter\nreads',RED),('Validate\nassembly',YELLOW)]
xs=np.linspace(1.2,12.8,len(steps))
for idx,(label,color) in enumerate(steps):
    x=xs[idx]
    ax.add_patch(FancyBboxPatch((x-0.8,3.1),1.6,1.15,boxstyle='round,pad=0.12,rounding_size=0.18',fc=color,ec='none',alpha=.9))
    ax.text(x,3.68,label,ha='center',va='center',fontsize=11,color='white' if color!=YELLOW else DARK,weight='bold')
    if idx<len(steps)-1:
        ax.add_patch(FancyArrowPatch((x+0.85,3.68),(xs[idx+1]-0.85,3.68),arrowstyle='-|>',mutation_scale=18,lw=2,color=GRAY))
ax.text(1.2,2.35,'Clean + chimeric labels', ha='center', fontsize=11, color=GRAY)
ax.text(6.95,2.35,'GB / CNN / BiGRU', ha='center', fontsize=11, color=GRAY)
ax.text(11.7,2.35,'SPAdes + Bandage', ha='center', fontsize=11, color=GRAY)
save(fig,'methodology.png')

# feature families
fig, ax = plt.subplots(figsize=(12,5.5))
clean(ax); ax.set_xlim(0,12); ax.set_ylim(0,5.5)
ax.text(0.3,5.0,'Evidence extracted from each read', fontsize=20, weight='bold', color=DARK)
ax.add_patch(FancyBboxPatch((0.45,2.45),1.55,.75,boxstyle='round,pad=0.1',fc=DARK,ec='none'))
ax.text(1.225,2.82,'Read',ha='center',va='center',color='white',fontsize=13,weight='bold')
labels=[('SA tags',BLUE),('Soft clipping',CYAN),('K-mer shift',PURPLE),('Microhomology',ORANGE),('MAPQ',GREEN)]
for i,(lab,col) in enumerate(labels):
    x=2.6+i*1.75
    ax.add_patch(FancyArrowPatch((2.05,2.82),(x-0.68,2.82),arrowstyle='-|>',mutation_scale=12,lw=1.4,color=GRAY,alpha=.45))
    ax.add_patch(FancyBboxPatch((x-0.65,2.35),1.3,.9,boxstyle='round,pad=0.1',fc=col,ec='none'))
    ax.text(x,2.8,lab,ha='center',va='center',color='white',fontsize=11,weight='bold')
for x in [4.5,6.3,8.1,9.9]:
    ax.add_patch(FancyArrowPatch((x,1.95),(x,1.55),arrowstyle='-|>',mutation_scale=12,lw=1.3,color=GRAY))
ax.add_patch(FancyBboxPatch((4.0,0.55),4.2,.7,boxstyle='round,pad=0.12',fc=LIGHT,ec=BLUE,lw=2))
ax.text(6.1,0.9,'23 numeric predictors',ha='center',va='center',fontsize=14,color=DARK,weight='bold')
save(fig,'feature_families.pdf')

# model architecture
fig, ax = plt.subplots(figsize=(12,5.6))
clean(ax); ax.set_xlim(0,12); ax.set_ylim(0,5.6)
ax.text(0.3,5.05,'Three modelling views of the same problem', fontsize=20, weight='bold', color=DARK)
cols=[('Engineered features','Gradient\nBoosting',BLUE),('One-hot sequence','1D CNN',CYAN),('4-mer tokens','Embedding\n+ BiGRU',PURPLE)]
for i,(inp,model,col) in enumerate(cols):
    x=1.0+i*3.7
    ax.add_patch(FancyBboxPatch((x,3.25),2.55,.72,boxstyle='round,pad=0.1',fc=LIGHT,ec=col,lw=2))
    ax.text(x+1.275,3.61,inp,ha='center',va='center',fontsize=12,color=DARK,weight='bold')
    ax.add_patch(FancyArrowPatch((x+1.275,3.18),(x+1.275,2.55),arrowstyle='-|>',mutation_scale=18,lw=2,color=GRAY))
    ax.add_patch(FancyBboxPatch((x,1.4),2.55,.85,boxstyle='round,pad=0.1',fc=col,ec='none'))
    ax.text(x+1.275,1.82,model,ha='center',va='center',fontsize=13,color='white',weight='bold')
    ax.add_patch(FancyArrowPatch((x+1.275,1.3),(x+1.275,.75),arrowstyle='-|>',mutation_scale=16,lw=1.8,color=GRAY))
    ax.text(x+1.275,.45,'Clean or chimeric',ha='center',va='center',fontsize=11,color=GRAY)
save(fig,'model_architecture.pdf')

# metrics comparison
models=['GB','CNN','BiGRU']; f1=[0.7765,0.9135,0.9523]; auc=[0.8459,0.9607,0.9849]
x=np.arange(len(models)); width=.35
fig, ax = plt.subplots(figsize=(9,5.2))
ax.bar(x-width/2,f1,width,label='F1-score',color=BLUE)
ax.bar(x+width/2,auc,width,label='ROC-AUC',color=CYAN)
ax.set_ylim(0,1.08); ax.set_xticks(x,models); ax.set_ylabel('Score')
ax.set_title('Held-out test performance')
ax.legend(frameon=False,loc='lower right')
for i,v in enumerate(f1): ax.text(i-width/2,v+.025,f'{v:.3f}',ha='center',fontsize=9)
for i,v in enumerate(auc): ax.text(i+width/2,v+.025,f'{v:.3f}',ha='center',fontsize=9)
ax.spines[['top','right']].set_visible(False)
fig.tight_layout()
save(fig,'gb_cnn_rnn_compare.png')

# confusion matrices
cms = {
 'cm_gradient_boosting.png':np.array([[3819,181],[1352,2648]]),
 'cnn_confusion.png':np.array([[3440,560],[165,3835]]),
 'rnn_confusion.png':np.array([[3751,249],[138,3862]])
}
for name, cm in cms.items():
    fig, ax = plt.subplots(figsize=(4.8,4.2))
    im=ax.imshow(cm,cmap='Blues')
    ax.set_xticks([0,1],['Clean','Chimera']); ax.set_yticks([0,1],['Clean','Chimera'])
    ax.set_xlabel('Predicted'); ax.set_ylabel('True')
    for i in range(2):
        for j in range(2):
            ax.text(j,i,str(cm[i,j]),ha='center',va='center',color='white' if cm[i,j]>cm.max()/2 else DARK,fontsize=14,weight='bold')
    ax.set_title(name.replace('.png','').replace('_',' ').title())
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    save(fig,name)

# gradient importance
features=['total clipped\nbases','k-mer JS\ndiv.','k-mer cosine\ndiff.','left soft\nclip','right soft\nclip','microhom.\nlength','microhom.\nGC']
vals=[0.117,0.074,0.022,0.017,0.010,0.002,0.001]
fig, ax = plt.subplots(figsize=(8.5,5))
y=np.arange(len(features))[::-1]
ax.barh(y, vals, color=[BLUE,CYAN,PURPLE,ORANGE,ORANGE,GRAY,GRAY])
ax.set_yticks(y, features)
ax.set_xlabel('Permutation importance')
ax.set_title('Gradient Boosting: strongest predictive evidence')
ax.spines[['top','right']].set_visible(False)
for yi,v in zip(y,vals): ax.text(v+.003,yi,f'{v:.3f}',va='center',fontsize=9)
fig.tight_layout()
save(fig,'gradient_imp_pair.png')

# assembly graph placeholders
def assembly(name, title, nodes):
    fig, axes = plt.subplots(2,2,figsize=(10,7))
    labels=['Unfiltered','GB','CNN','BiGRU']; colors=[RED,BLUE,CYAN,PURPLE]
    for ax,label,col,n in zip(axes.ravel(),labels,colors,nodes):
        ax.set_facecolor('#F9FAFB'); clean(ax); ax.set_xlim(-1,1); ax.set_ylim(-1,1)
        ax.set_title(label,fontsize=13,weight='bold',color=DARK)
        rng=np.random.default_rng(abs(hash(label+name))%10000)
        if n<=3:
            for k in range(n):
                angle=2*np.pi*k/max(n,1)
                x=.35*np.cos(angle); y=.35*np.sin(angle)
                ax.add_patch(Circle((x,y),.18,fc=col,ec='white',lw=1.5,alpha=.9))
            if n>1:
                pts=[(.35*np.cos(2*np.pi*k/n),.35*np.sin(2*np.pi*k/n)) for k in range(n)]
                for a,b in zip(pts,pts[1:]+pts[:1]):
                    ax.plot([a[0],b[0]],[a[1],b[1]],color=GRAY,lw=2,alpha=.8)
        else:
            pts=rng.normal(0,.35,(min(n,40),2))
            for p in pts:
                ax.add_patch(Circle((p[0],p[1]),.035,fc=col,ec='none',alpha=.8))
            for _ in range(55):
                a,b=rng.integers(0,len(pts),2)
                ax.plot([pts[a,0],pts[b,0]],[pts[a,1],pts[b,1]],color=GRAY,lw=.6,alpha=.45)
        ax.text(0,-.85,f'{n} node(s)' if n<20 else f'{n} nodes',ha='center',fontsize=12,color=GRAY)
    fig.suptitle(title,fontsize=18,weight='bold',color=DARK)
    fig.tight_layout(rect=[0,0,1,.94])
    save(fig,name)
assembly('assembly_20k_50.pdf','20K reads, 50% chimeras: graph simplification after filtering',[966,3,1,2])
assembly('assembly_3200_50.pdf','3200 reads, 50% chimeras: low-depth filtering risk',[2,1,2,8])

print('Figures created in', OUT)
